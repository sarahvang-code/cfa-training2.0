export const titles=['Welcome & Restaurant Tour','BOH Food Safety','Primary','Secondary','Machines','Breading','Fries','RSA Assessment','Closing'];
const starter=[['Clock in and meet your trainer','Restaurant tour','Uniform and handwashing expectations'],['Handwashing and glove use','Temperature checks','Prevent cross-contamination'],['Set up the primary station','Practice order assembly'],['Set up the secondary station','Practice station handoffs'],['Equipment overview','Safe operation and cleaning'],['Prepare the breading station','Review safe handling'],['Prepare the fry station','Review timers and holding procedures'],['Review restaurant safety expectations','Complete the trainer assessment'],['Complete station cleaning','Review the closing checklist']];
export function seed(){const categories=titles.map((title,i)=>({id:`c${i}`,title,description:i===0?'A great first day starts here.':'Practice the essentials with your trainer.',position:i}));const items=starter.flatMap((a,i)=>a.map((title,j)=>({id:`i${i}-${j}`,category_id:`c${i}`,section:i===0?'Welcome':'Station essentials',title,notes:'Example checklist item. Replace with your restaurant’s approved training.',link:'',position:j})));return {categories,items,members:[{id:'m1',name:'Alex Morgan',role:'Team member',auth_user_id:null},{id:'m2',name:'Jordan Lee',role:'Team member',auth_user_id:null},{id:'m3',name:'Taylor Reed',role:'Team member',auth_user_id:null}],progress:[],settings:{name:'Restaurant Training'}};}
export function stats(data,memberId,categoryId,department){const categoryIds=data.categories.filter(c=>!department||c.department===department).map(c=>c.id);const items=data.items.filter(i=>!i.hidden&&categoryIds.includes(i.category_id)&&(!categoryId||i.category_id===categoryId));const trained=items.filter(i=>data.progress.some(p=>p.member_id===memberId&&p.item_id===i.id&&p.status==='Trained')).length;const started=items.filter(i=>data.progress.some(p=>p.member_id===memberId&&p.item_id===i.id&&p.status!=='Not started')).length;return {total:items.length,trained,started,percent:items.length?Math.round(trained/items.length*100):0,status:items.length&&trained===items.length?'Trained':started?'In Training':'Not started'};}
export class TrainingStore{
 constructor(storage,config={}){this.storage=storage;this.config=config.url&&config.key?config:JSON.parse(storage.getItem('training-connection')||'{}');this.cloud=!!(this.config.url&&this.config.key);this.session=null;this.profile=null;this.data=this.cloud?{categories:[],items:[],members:[],progress:[],settings:{name:'Restaurant Training'}}:JSON.parse(storage.getItem('training-demo-v2')||'null')||seedReference();}
 persist(){this.storage.setItem('training-demo-v2',JSON.stringify(this.data));}
 async renameSection(categoryId,oldName,newName){if(!this.canEdit())throw Error('Owner access required.');if(this.cloud){await this.request('/rest/v1/items?category_id=eq.'+encodeURIComponent(categoryId)+'&section=eq.'+encodeURIComponent(oldName),{method:'PATCH',body:{section:newName}});await this.load();}else{this.data.items.filter(i=>i.category_id===categoryId&&i.section===oldName).forEach(i=>i.section=newName);this.persist();}}
 configure(url,key){url=url.trim().replace(/\/$/,'');key=key.trim();if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url))throw Error('Enter your Supabase project URL (https://your-project.supabase.co).');let valid=key.startsWith('sb_publishable_');if(key.startsWith('eyJ')){try{valid=JSON.parse(atob(key.split('.')[1])).role==='anon';}catch{valid=false;}}if(!valid)throw Error('Use the publishable key or legacy anon key, never a secret/service-role key.');this.storage.setItem('training-connection',JSON.stringify({url,key}));}
 async request(path,{method='GET',body,prefer='return=representation'}={}){if(!this.session&&method!=='GET')throw Error('Owner or trainer sign-in is required to save changes.');if(this.session&&this.session.expires_at<Date.now()/1000+60)await this.refresh();const r=await fetch(this.config.url+path,{method,headers:{apikey:this.config.key,...(this.session?{Authorization:`Bearer ${this.session.access_token}`}:{ }),'Content-Type':'application/json',Prefer:prefer},body:body===undefined?undefined:JSON.stringify(body)});const txt=await r.text();let value;try{value=txt?JSON.parse(txt):null;}catch{throw Error('Unexpected response from Supabase.');}if(!r.ok)throw Error(value?.message||value?.msg||value?.error_description||'Could not save. Check your connection and permissions.');return value;}
 async authRequest(path,body){
  const r=await fetch(this.config.url+path,{method:'POST',headers:{apikey:this.config.key,'Content-Type':'application/json'},body:JSON.stringify(body)});
  const text=await r.text();let value;
  try{value=text?JSON.parse(text):{};}catch{throw Error('Could not reach sign-in. Please try again.');}
  if(!r.ok){
   if(value.code==='otp_expired'||value.error_code==='otp_expired')throw Error('That sign-in link or code has already been used or has expired. Request a new email and use its latest link or code.');
   throw Error(value.msg||value.message||value.error_description||'Sign-in failed. Please try again.');
  }
  return value;
 }
 rememberSession(){
  if(this.session)this.storage.setItem('training-owner-session',JSON.stringify({project:this.config.url,session:this.session}));
 }
 clearSession(){
  this.session=null;this.profile=null;
  this.data.members=[];this.data.progress=[];
  this.storage.removeItem('training-owner-session');
 }
 async refresh(){
  if(this.refreshing)return this.refreshing;
  this.refreshing=(async()=>{
   try{
    const value=await this.authRequest('/auth/v1/token?grant_type=refresh_token',{refresh_token:this.session.refresh_token});
    this.session={...value,expires_at:value.expires_at||Date.now()/1000+(value.expires_in||3600)};
    this.rememberSession();
   }catch(e){this.clearSession();throw Error('Your session expired. Please sign in again.');}
   finally{this.refreshing=null;}
  })();
  return this.refreshing;
 }
 async requestSignInLink(email,redirectTo=this.config.siteUrl){
  let path='/auth/v1/otp';
  if(redirectTo){
   const url=new URL(redirectTo);
   if(url.protocol!=='https:'&&!(url.protocol==='http:'&&url.hostname==='localhost'))throw Error('The sign-in return address must use HTTPS.');
   url.hash='';url.search='';
   path+='?redirect_to='+encodeURIComponent(url.href);
  }
  await this.authRequest(path,{email:email.trim(),create_user:true});
 }
 async verifySignIn(email,input){
  let body;input=input.trim();const code=input.replace(/\s/g,'');
  if(/^\d{6,10}$/.test(code))body={email:email.trim(),token:code,type:'email'};
  else{
   let url;try{url=new URL(input);}catch{throw Error('Paste the sign-in link from your email, or the email code.');}
   if(url.origin!==this.config.url||url.pathname!=='/auth/v1/verify')throw Error('Copy the original sign-in link from your email. If you already opened it, request a new email.');
   const token_hash=url.searchParams.get('token_hash')||url.searchParams.get('token'),type=url.searchParams.get('type')||'email';
   if(!token_hash||!['email','magiclink','signup'].includes(type))throw Error('That link is not a valid email sign-in link.');
   body={token_hash,type};
  }
  const value=await this.authRequest('/auth/v1/verify',body);
  await this.activateSession(value,email);
 }
 async handleAuthCallback(input){
  const url=new URL(input),params=new URLSearchParams(url.hash.slice(1));
  const error=params.get('error_description')||url.searchParams.get('error_description');
  if(error){
   if((params.get('error_code')||url.searchParams.get('error_code'))==='otp_expired')throw Error('That sign-in link has already been used or has expired. Request a new email.');
   throw Error(error);
  }
  const access_token=params.get('access_token'),refresh_token=params.get('refresh_token');
  if(access_token&&refresh_token){
   if(params.get('type')==='recovery')throw Error('Use an owner sign-in email, rather than a password reset link.');
   await this.activateSession({access_token,refresh_token,expires_in:Number(params.get('expires_in'))||3600});
   return true;
  }
  const token_hash=url.searchParams.get('token_hash'),type=url.searchParams.get('type')||'email';
  if(token_hash&&['email','magiclink','signup'].includes(type)){
   const value=await this.authRequest('/auth/v1/verify',{token_hash,type});
   await this.activateSession(value);return true;
  }
  return false;
 }
 async activateSession(value,email){
  if(!value.access_token)throw Error('Sign-in did not return a session. Request a new email.');
  this.session={...value,expires_at:value.expires_at||Date.now()/1000+(value.expires_in||3600)};this.profile=null;
  try{
   // Resolve identity with Auth; never trust a stored user or a role from a URL.
   const user=await this.request('/auth/v1/user');
   if(!user?.id||!user.email_confirmed_at)throw Error('Please verify your email before signing in.');
   if(email&&user.email?.toLowerCase()!==email.trim().toLowerCase())throw Error('The sign-in link belongs to a different email address.');
   this.session.user=user;
   const profiles=await this.request('/rest/v1/access_users?user_id=eq.'+encodeURIComponent(user.id));
   this.profile=profiles[0];
   if(!this.profile||!['owner','trainer','member'].includes(this.profile.role))throw Error('This email has not been approved for owner or trainer access.');
   await this.load();this.rememberSession();
  }catch(e){this.clearSession();await this.load().catch(()=>{});throw e;}
 }
 async restoreSession(){
  let stored;try{stored=JSON.parse(this.storage.getItem('training-owner-session')||'null');}catch{this.clearSession();return false;}
  if(!stored)return false;
  if(stored.project!==this.config.url||!stored.session?.access_token){this.clearSession();return false;}
  await this.activateSession(stored.session);return true;
 }
 async logout(){try{if(this.session)await this.request('/auth/v1/logout',{method:'POST'});}finally{this.clearSession();await this.load();}}
 async load(){if(!this.cloud)return;const [categories,items,settings]=await Promise.all(['categories?order=position','items?order=position','settings'].map(t=>this.request('/rest/v1/'+t)));let members=[],progress=[];if(this.session&&this.profile)[members,progress]=await Promise.all(['members?order=name','progress'].map(t=>this.request('/rest/v1/'+t)));this.data={categories,items,members,progress,settings:settings[0]||{name:'Restaurant Training'}};}
 canEdit(){return !this.cloud||this.profile?.role==='owner';}
 canTrain(){return !this.cloud||['owner','trainer'].includes(this.profile?.role);}
 async save(table,row){if(table==='progress'&&!this.canTrain())throw Error('Only trainers and owners can record progress.');if(['categories','items','settings'].includes(table)&&!this.canEdit())throw Error('Only the owner can edit training.');if(table==='members'&&!this.canTrain())throw Error('Only trainers and owners can manage team members.');if(this.cloud){await this.request('/rest/v1/'+table+(table==='progress'?'?on_conflict=member_id,item_id':''),{method:'POST',body:row,prefer:'resolution=merge-duplicates,return=representation'});await this.load();return;}if(table==='settings')this.data.settings=row;else{const rows=this.data[table];const index=rows.findIndex(r=>table==='progress'?r.member_id===row.member_id&&r.item_id===row.item_id:r.id===row.id);if(index<0)rows.push(row);else rows[index]={...rows[index],...row};}this.persist();}
 async remove(table,id){if(table==='members'?!this.canTrain():!this.canEdit())throw Error('You do not have permission to delete this record.');if(this.cloud){await this.request(`/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`,{method:'DELETE'});await this.load();return;}this.data[table]=this.data[table].filter(r=>r.id!==id);if(table==='categories'){const removed=this.data.items.filter(i=>i.category_id===id).map(i=>i.id);this.data.items=this.data.items.filter(i=>i.category_id!==id);this.data.progress=this.data.progress.filter(p=>!removed.includes(p.item_id));}if(table==='items')this.data.progress=this.data.progress.filter(p=>p.item_id!==id);if(table==='members')this.data.progress=this.data.progress.filter(p=>p.member_id!==id);this.persist();}
}
export function seedReference(){
 const data=seed();data.categories.forEach(c=>c.department='BOH');data.items.forEach(i=>i.hidden=false);data.members.forEach(m=>{m.status_boh='In Training';m.status_foh='In Training';});
 const groups={
  'Welcome & Restaurant Tour':{'Welcome':['Clock In','Restaurant Tour'],'What makes Chick-fil-A Unique?':['How Truett Cathy Built a Good Name']},
  'BOH Food Safety':{'Food Safety Basics':['Handwashing before food handling','Understand cross-contamination','Review approved food temperature procedures']},
  'Primary':{'Station Setup':['Prepare the primary station'],'Orders':['Build sandwiches','Follow special-order instructions'],'AHA + Communication':['Communicate with bagger and breader','Follow the PAN system','Use AHA tracking']},
  'Secondary':{'Orders':['Use nugget/strip box tabs and labels correctly','Cobb/customized salads','Place items in correct chutes','Bake and bag cookies'],'AHA + Communication':['Communicate with bagger and breader','Follow the PAN system','Use AHA tracking']},
  'Breading':{'Breading':['Bread filets','Bread nuggets','Bread strips'],'Coater + Milkwash':['Follow chicken load amounts','Add new coater when needed','Properly sift coater','Prepare milkwash'],'Grilled + Rotation':['Drop grilled filets/nuggets','Review rotation with the trainer']},
  'Closing':{'Closing Boards':['Clean and sanitize boards','Restock the station'],'Closing Machines':['Complete machine cleaning procedures'],'Closing Breading Table':['Clean and sanitize the breading table'],'Closing Dishes':['Wash and organize dishes']}
 };
 for(const c of data.categories){if(groups[c.title]){data.items=data.items.filter(i=>i.category_id!==c.id);let position=0;for(const [section,names]of Object.entries(groups[c.title]))for(const title of names)data.items.push({id:`${c.id}-ref-${position}`,category_id:c.id,section,title,notes:'',link:'',position:position++,hidden:false});}}
 const foh={
  'Welcome & Restaurant Tour':groups['Welcome & Restaurant Tour'],
  'FOH Food Safety':{'Food Safety Basics':['Handwashing before food handling','Prevent cross-contamination','Review approved cleaning and sanitizing procedures']},
  'Winning Hearts Everyday':{'Second-Mile Service':['Understands the second-mile service portion of Winning Hearts Everyday','Language of Hospitality','Proactive','Personal','Generous','Attentive and Friendly','Above and Beyond','Emotional Connections','Service Recovery']},
  'FOH Basic Training':{'Guest Experience':['Uses CORE 4 with guests','Practice order taking','Practice payment handling','Review restaurant service expectations']},
  'Bagger Training':{'Bagging':['Bags all food items with reasonable speed and excellent accuracy','Understands what bags to use and when','Proficient communication with the BOH team','Basic understanding of the bagging matrix and dine-ready meals','Understands Prep Kanban system','Understands the KPS and bump bar system','Proficient communication with the saucer/stuffer position when applicable','Utilizes CORE 4 when handing out food to guests','Awareness of mobile and third-party beverage screen and prepares items when applicable','Sanitizes the chutes and other food prep surfaces every 4 hours']},
  'FSA Assessments':{'Assessment Check':['Complete the trainer assessment','Review areas for continued practice']},
  'RSA Assessments':{'Assessment Check':['Complete the restaurant safety assessment','Review areas for continued practice']},
  'Closing':{'FOH Closing':['Lowboy fridge is cleaned and polished','Sauce wall is stocked and surrounding countertop is clean','Tea brewer parts are emptied, cleaned, and returned to the correct location','Dry storage items are stocked and organized appropriately','All countertops are cleaned and sanitized with no residue','Line stanchions are separated and stowed away','Floor is swept, scrubbed, squeegeed, and mopped','FOH closet floor is swept underneath shelving']}
 };
 let position=0;for(const [title,sections]of Object.entries(foh)){const id='foh-'+position;data.categories.push({id,title,description:'Select a team member in Trainer View to record training status.',department:'FOH',position:position++});let p=0;for(const [section,names]of Object.entries(sections))for(const t of names)data.items.push({id:id+'-'+p,category_id:id,section,title:t,notes:'',link:'',position:p++,hidden:false});}
 return data;
}
