import {TrainingStore,stats} from './store.js';
import {getBohBuild,renderBuildDiagram} from './boh-builds.js';
const store=new TrainingStore(localStorage,window.TRAINING_CONFIG||{});let page='training',categoryId=null,sectionView=null,department=localStorage.getItem('training-department')||'BOH',memberId='',filter='All',search='',editing=false,busy=false,loaded=!store.cloud,loadError='',itemDraft=null;const app=document.querySelector('#app'),dialog=document.querySelector('#dialog');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const paths={book:'M4 4h6a3 3 0 0 1 3 3v14a4 4 0 0 0-4-2H4z M20 4h-4a3 3 0 0 0-3 3 M20 4v15h-3',check:'m5 12 4 4 10-10',team:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M16 3a4 4 0 0 1 0 8 M22 21v-2a4 4 0 0 0-3-3 M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0',chart:'M4 20V10 M10 20V4 M16 20v-7 M22 20H2',settings:'M12 3v3 M12 18v3 M3 12h3 M18 12h3 M5.6 5.6l2 2 M16.4 16.4l2 2 M5.6 18.4l2-2 M16.4 7.6l2-2 M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0',arrow:'M5 12h14 M14 7l5 5-5 5',back:'M19 12H5 M10 7l-5 5 5 5',link:'M15 3h6v6 M10 14 21 3 M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5',search:'M21 21l-6-6 M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0',shield:'M12 3 3 7v5c0 5 9 9 9 9s9-4 9-9V7z',clock:'M12 8v5l3 2 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',clipboard:'M9 5H5v16h14V5h-4 M9 3h6v4H9z M8 12h8 M8 16h5',plus:'M12 5v14 M5 12h14',close:'m6 6 12 12 M6 18 18 6',fire:'M12 2c0 7-7 7-7 13a7 7 0 0 0 14 0c0-4-4-5-4-9-1 4-3 5-3 7'};
const icon=n=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[n]||paths.clipboard}"/></svg>`;
function badge(s){return `<span class="badge ${s==='Trained'?'trained':s==='In Training'?'training':''}">${esc(s)}</span>`;}
function toast(message,error=false){const el=document.querySelector('#toast');el.textContent=message;el.style.display='block';el.style.background=error?'#9b1e36':'#293c2e';clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.style.display='none',4500);}
async function run(fn){if(busy){render();return;}busy=true;try{await fn();render();}catch(e){toast(e.message,true);}finally{busy=false;render();}}
const current=()=>store.data.members.find(m=>m.id===memberId);
function totalStats(){const sums=store.data.members.map(m=>stats(store.data,m.id));return {trained:sums.filter(s=>s.status==='Trained').length,inTraining:sums.filter(s=>s.status!=='Trained').length,average:sums.length?Math.round(sums.reduce((a,s)=>a+s.percent,0)/sums.length):0};}
function selected(){return `<div class="selector"><label for="member-select">${page==='trainer'?'Training team member':'Team member'}</label><select id="member-select" ${store.cloud&&store.profile?.role==='member'?'disabled':''}><option value="">Choose a team member</option>${store.data.members.map(m=>`<option value="${esc(m.id)}" ${m.id===memberId?'selected':''}>${esc(m.name)}</option>`).join('')}</select><span class="tiny">${store.canTrain()?'Select a team member to record training status.':'Your trainer records your training progress.'}</span></div>`;}
function shell(content){const name=store.data.settings.name||'Restaurant Training';return `<header class="reference-header"><div class="header-inner"><div class="brand"><span class="brand-symbol">${icon('clipboard')}</span><strong>${esc(department)} TRAINING</strong></div><div class="actions"><button class="department-button ${department==='BOH'?'active':''}" data-department="BOH">BOH</button><button class="department-button ${department==='FOH'?'active':''}" data-department="FOH">FOH</button><button data-action="home">Home</button><button class="plain" data-nav="settings" aria-label="Workspace settings">${icon('settings')}</button></div></div></header><main class="reference-main">${!store.cloud?'<div class="demo-banner"><span><strong>Preview</strong> · Example team. Editable starter content. Saved on this device only.</span><button data-action="connect">Connect Supabase →</button></div>':`<div class="connection-status"><span class="dot ${store.session?'green':''}"></span>${store.profile?'Owner / trainer workspace':'Open training reference'}${store.profile?'<button class="plain" data-action="logout">Sign out</button>':'<button class="plain" data-action="owner-login">Owner sign-in</button>'}</div>`}${content}<footer><span>${esc(name)}</span><button class="plain" data-action="install">Add to home screen</button></footer></main><nav class="reference-nav" aria-label="Main navigation"><div>${[['training','Training'],['progress','My Progress'],['trainer','Trainer View']].map(([id,t])=>`<button class="${page===id?'active':''}" data-nav="${id}" ${page===id?'aria-current="page"':''}>${t}</button>`).join('')}</div></nav>`;}
function head(title,desc,actions='',eyebrow='YOUR TRAINING WORKSPACE'){return `<div class="page-head"><div><div class="eyebrow">${eyebrow}</div><h1>${esc(title)}</h1><p class="sub">${esc(desc)}</p></div><div class="actions">${actions}</div></div>`;}
function overview(){const n=totalStats();return `<div class="stats"><div class="stat"><div class="stat-label">Team members ${icon('team')}</div><strong>${store.data.members.length.toString().padStart(2,'0')}</strong><small>Learning and growing together</small></div><div class="stat"><div class="stat-label">In training ${icon('clock')}</div><strong>${n.inTraining.toString().padStart(2,'0')}</strong><small>${n.trained} fully trained across all categories</small></div><div class="stat"><div class="stat-label">Team completion ${icon('chart')}</div><strong>${n.average}%</strong><small>Average checklist completion</small></div></div>`;}
function training(){const categories=store.data.categories.filter(c=>c.department===department).sort((a,b)=>a.position-b.position);const welcome=categories.find(c=>/welcome/i.test(c.title));return head(department+' Training','Training reference and shared progress tracker.')+`<div class="reference-menu">${welcome?`<button class="welcome-button" data-category="${esc(welcome.id)}">${esc(welcome.title)}<span>›</span></button>`:''}${categories.filter(c=>c!==welcome).map(c=>`<button data-category="${esc(c.id)}">${esc(c.title)}<span>›</span></button>`).join('')}<button data-nav="progress">My Progress<span>›</span></button>${store.canTrain()?'<button data-action="add-member">Add Team Member<span>›</span></button>':''}<button data-nav="team">All Progress<span>›</span></button>${store.canEdit()?'<button data-action="open-editor">Edit Training<span>›</span></button>':''}</div><p class="starter-note">Browse a training checklist and open its Pathway resources. Select FOH or BOH above to switch departments.</p>`;}
const buildSteps=new Map();
let buildTimer;
function buildCaption(build,step){return `${step} of ${build.steps.length}: ${build.steps[step-1]}`;}
function buildControls(item,large=false){
 const build=getBohBuild(item.id);
 if(!build)return '';
 const step=buildSteps.get(item.id),art=renderBuildDiagram(item.id,step??build.steps.length),id=esc(item.id);
 const artwork=large?`<div class="build-artwork build-artwork-large" data-build-artwork="${id}">${art}</div>`:
  `<button type="button" class="build-thumbnail" data-build-enlarge="${id}" aria-label="Enlarge ${esc(item.title)} build">
   <span class="build-artwork" data-build-artwork="${id}">${art}</span><span>Tap to enlarge</span>
  </button>`;
 return `<div class="build-controls${large?' build-controls-large':''}">
  ${artwork}
  <button type="button" class="primary build-play" data-build-play="${id}"><svg viewBox="0 0 12 12" aria-hidden="true" focusable="false"><path d="M3 1.5v9L10 6z" fill="currentColor"/></svg> Play / Replay build</button>
  <div class="build-step" role="status" data-build-step="${id}">${step?esc(buildCaption(build,step)):''}</div>
  ${large?`<ol class="build-legend" aria-label="Build order">${build.steps.map(s=>`<li>${esc(s)}</li>`).join('')}</ol>`:''}
 </div>`;
}
function showBuildStep(itemId,step){
 buildSteps.set(itemId,step);
 const build=getBohBuild(itemId),art=renderBuildDiagram(itemId,step,true);
 const visibleRoots=dialog.open?[app,dialog]:[app];
 for(const root of visibleRoots){
  root.querySelectorAll('[data-build-artwork]').forEach(el=>{if(el.dataset.buildArtwork===itemId)el.innerHTML=art;});
  root.querySelectorAll('[data-build-step]').forEach(el=>{if(el.dataset.buildStep===itemId)el.textContent=buildCaption(build,step);});
 }
}
function playBuild(itemId){
 const build=getBohBuild(itemId);
 if(!build)return;
 clearTimeout(buildTimer);
 const advance=(step)=>{
  showBuildStep(itemId,step);
  if(step<build.steps.length)buildTimer=setTimeout(()=>advance(step+1),1500);
 };
 advance(1);
}
function bindBuildControls(root){
 root.querySelectorAll('[data-build-play]').forEach(button=>button.onclick=()=>playBuild(button.dataset.buildPlay));
 root.querySelectorAll('[data-build-enlarge]').forEach(button=>button.onclick=()=>{
  const item=store.data.items.find(i=>i.id===button.dataset.buildEnlarge);
  if(!item||!getBohBuild(item.id))return;
  modal(item.title,buildControls(item,true));
  bindBuildControls(dialog);
 });
}
function trainingItem(item,showEdit){
 const progress=store.data.progress.find(p=>p.item_id===item.id&&p.member_id===memberId);
 const status=progress?.status||'Not started';
 const id=esc(item.id),title=esc(item.title),canRecord=store.canTrain()&&memberId&&!item.hidden;
 return `<div class="reference-item ${item.hidden?'hidden-item':''}">
  <input class="training-checkbox" type="checkbox" aria-label="Mark ${title} trained" data-check="${id}" ${status==='Trained'?'checked':''} ${canRecord?'':'disabled'}>
  <div class="item-info"><h3>${title}${item.hidden?' <span class="badge">Hidden</span>':''}</h3>
   ${item.notes?`<p class="item-instructions">${esc(item.notes)}</p>`:''}
   ${buildControls(item)}
   ${/^https:\/\//i.test(item.link)?`<a class="pathway-link" href="${esc(item.link)}" target="_blank" rel="noopener noreferrer">Open Link ${icon('link')}</a>`:''}
   ${canRecord?`<select data-status="${id}" aria-label="Status for ${title}">${['Not started','In Training','Trained'].map(st=>`<option ${status===st?'selected':''}>${st}</option>`).join('')}</select>`:''}
   ${showEdit?`<div class="actions"><button data-edit-item="${id}">Edit</button>${item.hidden?`<button data-restore-item="${id}">Restore</button>`:`<button data-hide-item="${id}">Delete</button>`}</div>`:''}
  </div>
 </div>`;
}
function category(){
 const c=store.data.categories.find(c=>c.id===categoryId);
 if(!c){categoryId=null;return training();}
 const edit=store.canEdit(),isEditor=page==='editor',showEdit=edit&&(editing||isEditor);
 let items=store.data.items.filter(i=>i.category_id===c.id&&(showEdit||!i.hidden)).sort((a,b)=>a.position-b.position);
 const sectionName=i=>i.section||'Training checklist';
 const sections=[...new Set(items.map(sectionName))];
 if(c.title==='Closing'&&department==='BOH'&&!sectionView&&!isEditor)return head('Closing','Choose a closing area.',edit?'<button data-action="open-editor">Edit Training</button>':'')+`<div class="reference-menu">${sections.map(section=>`<button data-section-view="${esc(section)}">${esc(section)}<span>›</span></button>`).join('')}</div><button class="back" data-action="back">${icon('back')} Back to training</button>`;
 if(sectionView&&!isEditor)items=items.filter(i=>i.section===sectionView);
 const shownSections=[...new Set(items.map(sectionName))];
 return head(isEditor?'Edit Training':sectionView||c.title,isEditor?'Edit titles, section headings, instructions, and links. Hidden items can be restored here.':store.profile?'Select a team member in Trainer View to record training status.':'Browse this training checklist and its resources.')+
  (isEditor?`<select id="editor-category" aria-label="Training category">${store.data.categories.filter(x=>x.department===department).map(x=>`<option value="${esc(x.id)}" ${x.id===c.id?'selected':''}>${esc(x.title)}</option>`).join('')}</select><div class="editor-actions"><button data-action="edit-category">Edit page title</button><button data-action="add-category">Add category</button></div>`:
   `<div class="editor-actions">${edit?'<button data-action="edit-category">Edit page title</button><button data-action="edit-mode">'+(editing?'Finish editing':'Edit Training')+'</button>':''}</div>`)+
  (page==='trainer'||memberId?selected():'')+
  shownSections.map(section=>`<section class="panel"><div class="panel-heading"><h3>${esc(section)}</h3>${showEdit?`<button data-edit-section="${esc(section)}">Edit heading</button>`:''}</div>
   ${items.filter(i=>sectionName(i)===section).map(i=>trainingItem(i,showEdit)).join('')}
   ${showEdit?`<button class="add-item" data-add-section-item="${esc(section)}">Add Item</button>`:''}
  </section>`).join('')+
  (showEdit?'<button class="primary" data-action="add-item">+ Add item or section</button>':'')+
  (!items.length?'<div class="empty"><h3>This checklist is ready for your content</h3><p>Use Edit Training to add items, notes, and Pathway links.</p></div>':'')+
  (sectionView?'<button class="back" data-action="closing-back">Back to closing areas</button>':'');
}
function myProgress(trainer=false){if(store.cloud&&!store.profile)return restricted(trainer?'Trainer View':'My Progress');if(trainer&&!store.canTrain())return head('Trainer View','Your trainer records checklist progress.')+'<div class="empty"><p>Ask your project owner for trainer access.</p></div>';const categories=store.data.categories.filter(c=>c.department===department);return head(trainer?'Trainer View':'My Progress',trainer?'Select a team member and open a checklist to record training.':'Track completion across every training category.')+selected()+(memberId?categories.map(c=>{const st=stats(store.data,memberId,c.id);return `<button class="progress-card" data-category="${esc(c.id)}"><h3>${esc(c.title)}</h3><div class="progress-bar"><span style="width:${st.percent}%"></span></div><p>${st.trained} of ${st.total} trained · ${st.percent}%</p></button>`;}).join('')+'<button data-action="home">Open training checklists</button>':'<div class="empty"><h3>Choose a team member</h3><p>Select a name above to see category progress.</p></div>');}
function team(){if(store.cloud&&!store.profile)return restricted('All Progress');return head('All Progress','Set an overall status and open each team member’s checklist progress.',store.canTrain()?'<button class="primary" data-action="add-member">Add Team Member</button>':'')+store.data.members.map(m=>{const st=stats(store.data,m.id,null,department),status=m['status_'+department.toLowerCase()]||'In Training';return `<section class="panel team-progress"><div class="panel-heading"><h3>${esc(m.name)} — Overall ${department} training</h3>${store.canTrain()?`<button data-edit-member="${esc(m.id)}">Edit member</button>`:''}</div>${store.canTrain()?`<select class="overall-status ${status==='Trained'?'is-trained':''}" data-overall-member="${esc(m.id)}" aria-label="Overall ${department} training for ${esc(m.name)}"><option ${status==='In Training'?'selected':''}>In Training</option><option ${status==='Trained'?'selected':''}>Trained</option></select>`:badge(status)}<p class="tiny">Overall status is set by a leader; checklist completion is tracked separately.</p><button class="open-progress" data-view-member="${esc(m.id)}">Open ${esc(m.name)}’s progress — ${st.percent}% <span>›</span></button></section>`;}).join('')+(!store.data.members.length?'<div class="empty"><h3>Add your first team member</h3><p>Then start recording training in Trainer View.</p></div>':'');}
function settings(){if(store.cloud&&!store.profile)return head('Restaurant Training','Training resources for your team.')+'<section class="panel"><h2>Add to home screen</h2><p class="helper">Open this app in Safari on your phone or iPad, tap Share, then Add to Home Screen.</p><button data-action="install">Installation instructions</button></section><button data-action="owner-login">Owner sign-in</button>';return head('Make it your restaurant.','Set up your workspace, keep a backup, and connect your team.','','WORKSPACE SETTINGS')+`<div class="settings-grid"><section class="panel"><div class="eyebrow">YOUR WORKSPACE</div><h2 style="margin-top:12px">Restaurant details</h2><p>${esc(store.data.settings.name)}</p>${store.canEdit()?'<button data-action="rename">Edit restaurant name</button>':''}</section><section class="panel"><div class="eyebrow">SHARED TRAINING</div><h2 style="margin-top:12px">${store.cloud?'Supabase connection':'Bring your team together'}</h2><p>${store.cloud?'Training content and progress are read from your Supabase project. Sign in on another device with the same project to see shared changes.':'This preview saves to this browser. Connect a Supabase project to keep training and progress consistent across devices.'}</p><div class="actions"><button class="primary" data-action="connect">${store.cloud?'Connection settings':'Connect Supabase'}</button><button data-action="setup">Setup guide</button></div></section><section class="panel"><div class="eyebrow">AT YOUR FINGERTIPS</div><h2 style="margin-top:12px">Add to home screen</h2><p>Keep training one tap away on your phone or iPad. Open in Safari, tap Share, then Add to Home Screen.</p><button data-action="install">Installation instructions</button></section><section class="panel"><div class="eyebrow">A COPY YOU CAN KEEP</div><h2 style="margin-top:12px">Backup your training</h2><p>Download your categories, checklist items, team records, and progress as JSON. Code versions are saved separately.</p><button data-action="backup">Download data backup</button></section></div><p class="status-note">Pathway links open in Pathway. Team members may need to sign in there. Opening a link does not automatically complete an item.</p>`;}
function restricted(title){return head(title,'A leader sign-in is required to view or record team progress.')+'<div class="empty"><h3>Owner and trainer access</h3><p>Training checklists are open to view. Sign in as a leader to work with team records.</p><button class="primary" data-action="owner-login">Owner sign-in</button></div>';}
function render(){if(itemDraft&&!store.canEdit())itemDraft=null;if(store.cloud&&store.profile?.role==='member')memberId=store.data.members.find(m=>m.auth_user_id===store.session?.user.id)?.id||'';else if(memberId&&!store.data.members.some(m=>m.id===memberId))memberId='';app.innerHTML=shell(!loaded?'<div class="loading">Loading training…</div>':loadError?'<div class="empty"><h3>Could not load training</h3><p>'+esc(loadError)+'</p><button data-action="reload-training">Try again</button></div>':itemDraft?bohItemEditor():categoryId?category():({training,progress:()=>myProgress(),trainer:()=>myProgress(true),team,settings,editor:()=>head('Edit Training','Add your first training category.')+'<button class="primary" data-action="add-category">Add category</button>'}[page])());bind();}
function modal(title,body,onSubmit,successMessage='Saved successfully.'){
 dialog.innerHTML=`<div class="modal-top"><h2>${esc(title)}</h2><button class="plain" data-close aria-label="Close dialog">${icon('close')}</button></div>${body}`;
 dialog.querySelector('[data-close]').onclick=()=>dialog.close();dialog.querySelectorAll('[data-cancel]').forEach(b=>b.onclick=()=>dialog.close());
 const f=dialog.querySelector('form');
 if(f)f.onsubmit=async e=>{
  e.preventDefault();const button=f.querySelector('[type=submit]'),label=button.textContent;button.disabled=true;button.textContent='Working…';f.querySelector('.form-error').textContent='';
  try{
   const close=await onSubmit(new FormData(f));
   if(close===false||f!==dialog.querySelector('form')||!dialog.open)return;
   dialog.close();render();toast(successMessage);
  }catch(err){if(f===dialog.querySelector('form'))f.querySelector('.form-error').textContent=err.message;}
  finally{button.disabled=false;button.textContent=label;}
 };
 if(!dialog.open)dialog.showModal();
}
const field=(label,name,value='',type='text',required=false)=>`<div class="field"><label for="f-${name}">${label}</label>${type==='textarea'?`<textarea id="f-${name}" name="${name}">${esc(value)}</textarea>`:`<input id="f-${name}" name="${name}" type="${type}" value="${esc(value)}" ${required?'required':''} ${name==='password'?'autocomplete="current-password"':''}>`}</div>`;
const form=(body,button='Save')=>`<form>${body}<p class="form-error" role="alert"></p><div class="form-actions"><button type="button" data-cancel>Cancel</button><button class="primary" type="submit">${button}</button></div></form>`;
function editCategory(c){modal(c?'Edit category':'Add category',form(field('Category name','title',c?.title||'','text',true)+field('Description','description',c?.description||'','textarea')+(c?'<button type="button" class="danger" id="delete-category">Delete category and its items</button>':'')),async f=>{const title=f.get('title').trim();if(!title)throw Error('Enter a category name.');await store.save('categories',{id:c?.id||crypto.randomUUID(),title,description:f.get('description').trim(),department:c?.department||department,position:c?.position??store.data.categories.filter(c=>c.department===department).length});});if(c)dialog.querySelector('#delete-category').onclick=()=>{dialog.close();confirmDelete('categories',c.id,c.title);};}
async function saveTrainingItem(f,item,section,category){
 const title=f.get('title').trim();
 let link=f.get('link').trim();
 if(!title)throw Error('Enter a checklist title.');
 if(link){
  let target;try{target=new URL(link);}catch{}
  if(target?.protocol!=='https:')throw Error('Use an HTTPS link for your training resource.');
  link=target.href;
 }
 const latest=item?store.data.items.find(i=>i.id===item.id):null;
 if(item&&!latest)throw Error('This item is no longer in the checklist.');
 const lastPosition=Math.max(-1,...store.data.items.filter(i=>i.category_id===category).map(i=>i.position));
 await store.save('items',{
  id:latest?.id||crypto.randomUUID(),category_id:category,title,
  section:String(f.get('section')??section??'').trim()||'Training checklist',
  notes:f.get('notes').trim(),link,hidden:latest?.hidden??false,position:latest?.position??(lastPosition+1)
 });
}
function editItem(item,section){
 if(!store.canEdit()||!categoryId)return;
 if(department==='BOH'){
  itemDraft={item,section:item?.section||section||'Training checklist',category:categoryId,returnScroll:window.scrollY,askSection:!item&&!section};
  render();window.scrollTo(0,0);app.querySelector('#boh-editor-title')?.focus({preventScroll:true});
  return;
 }
 const category=categoryId;
 modal(item?'Edit training item':'Add training item',form(field('Checklist title','title',item?.title||'','text',true)+field('Section heading','section',item?.section||section||'Training checklist','text',true)+field('Training notes','notes',item?.notes||'','textarea')+field('Pathway link (optional)','link',item?.link||'','url')+'<p class="helper">Copy the actual resource link from Pathway. It opens in a new tab and may require Pathway sign-in.</p>'),f=>saveTrainingItem(f,item,section,category));
}
function bohItemEditor(){
 const {item,section,category,askSection}=itemDraft;
 const categoryName=store.data.categories.find(c=>c.id===category)?.title||'BOH';
 return `<section class="boh-item-editor" aria-labelledby="boh-editor-title">
  <p class="boh-editor-context">${esc(categoryName)} <span aria-hidden="true">›</span> ${esc(section)}</p>
  <h1 id="boh-editor-title" tabindex="-1">${item?'Edit Training Item':'Add Training Item'}</h1>
  <form id="boh-item-form">
   <div class="field"><label for="boh-item-title">Title</label><input id="boh-item-title" name="title" value="${esc(item?.title||'')}" required></div>
   <div class="field"><label for="boh-item-notes">Instructions</label><textarea id="boh-item-notes" name="notes" rows="6">${esc(item?.notes||'')}</textarea></div>
   <div class="field"><label for="boh-item-link">Link (optional)</label><input id="boh-item-link" name="link" type="url" placeholder="https://" value="${esc(item?.link||'')}"></div>
   <details class="boh-editor-section"${askSection?' open':''}><summary>Section heading</summary>
    <div class="field"><label for="boh-item-section">Heading name</label><input id="boh-item-section" name="section" value="${esc(section)}"></div>
   </details>
   <p class="form-error" role="alert"></p>
   <div class="form-actions"><button class="primary" type="submit">${item?'Save Changes':'Add Item'}</button><button type="button" data-cancel-item-editor>Cancel</button></div>
  </form>
 </section>`;
}
function closeBohEditor(){
 const scroll=itemDraft?.returnScroll||0;
 itemDraft=null;render();window.scrollTo(0,scroll);
}
function bindBohItemEditor(){
 const form=app.querySelector('#boh-item-form');
 if(!form)return;
 const submit=form.querySelector('[type=submit]'),cancel=form.querySelector('[data-cancel-item-editor]');
 cancel.onclick=closeBohEditor;
 form.onsubmit=async e=>{
  e.preventDefault();
  if(submit.disabled)return;
  const draft=itemDraft,label=submit.textContent,error=form.querySelector('.form-error');
  submit.disabled=cancel.disabled=true;submit.textContent='Saving…';error.textContent='';
  try{
   await saveTrainingItem(new FormData(form),draft.item,draft.section,draft.category);
   if(itemDraft===draft)closeBohEditor();
   toast('Training item saved.');
  }catch(e){if(itemDraft===draft)error.textContent=e.message;}
  finally{submit.disabled=cancel.disabled=false;submit.textContent=label;}
 };
}
function editMember(m){modal(m?'Edit team member':'Add team member',form(field('Full name','name',m?.name||'','text',true)+field('Position','role',m?.role||'Team member')+(m?'<button type="button" class="danger" id="delete-member">Delete team member and progress</button>':'')),async f=>{const name=f.get('name').trim();if(!name)throw Error('Enter a team member name.');await store.save('members',{id:m?.id||crypto.randomUUID(),name,role:f.get('role').trim()||'Team member',auth_user_id:m?.auth_user_id||null,status_boh:m?.status_boh||'In Training',status_foh:m?.status_foh||'In Training'});});if(m)dialog.querySelector('#delete-member').onclick=()=>{dialog.close();confirmDelete('members',m.id,m.name);};}
function confirmDelete(table,id,title){modal('Delete this record?',form(`<p class="helper">Delete “${esc(title)}”? ${table==='categories'?'Its checklist items and progress will also be removed.':table==='members'?'This team member’s progress will also be removed.':'Its recorded progress will also be removed.'} Download a backup first if you need to keep a copy.</p>`,'Delete'),async()=>{await store.remove(table,id);if(table==='categories')categoryId=null;});}
function ownerLogin(email=localStorage.getItem('training-pending-email')||'',error=''){
 modal('Owner sign-in',form('<p class="helper">Enter your approved owner or trainer email. No password is needed.</p>'+field('Email','email',email,'email',true)+'<button type="button" id="existing-sign-in">I already have a link or code</button>','Send sign-in email'),async f=>{
  const email=f.get('email').trim(),sendingForm=dialog.querySelector('form');
  let notice='';
  try{await store.requestSignInLink(email,new URL('./',location.href).href);}
  catch(e){if(e.code!=='over_email_send_rate_limit')throw e;notice=e.message;}
  localStorage.setItem('training-pending-email',email);
  if(dialog.open&&dialog.querySelector('form')===sendingForm)ownerVerification(email,!notice,notice);
  return false;
 });
 dialog.querySelector('#existing-sign-in').onclick=()=>{const input=dialog.querySelector('[name=email]');if(input.reportValidity())ownerVerification(input.value.trim());};
 if(error)dialog.querySelector('.form-error').textContent=error;
}
function ownerVerification(email,emailJustSent=false,notice=''){
 modal('Finish sign-in',form((notice?'<p class="helper" role="status">'+esc(notice)+'</p>':'')+'<p class="helper">'+(emailJustSent?'Email sent to ':'Signing in as ')+'<strong>'+esc(email)+'</strong>. Paste your email code or copy the link from the newest email without opening it.</p><p class="helper">Already clicked it and got a Safari error? Copy the address from that Safari tab and paste it below.</p>'+field('Email code or sign-in link','verification','','text',true)+'<button type="button" id="new-sign-in">Request a new email</button>','Verify and sign in'),async f=>{
  await store.verifySignIn(email,f.get('verification'));localStorage.removeItem('training-pending-email');page='training';categoryId=null;memberId='';
 },'Signed in successfully.');
 const verification=dialog.querySelector('[name=verification]');verification.autocomplete='one-time-code';verification.spellcheck=false;verification.setAttribute('autocapitalize','off');
 dialog.querySelector('#new-sign-in').onclick=()=>ownerLogin(email);
}
async function initializeTraining(){
 busy=true;let authError='',signedIn=false;
 const callback=new URL(location.href),fragment=new URLSearchParams(callback.hash.slice(1));
 const hasCallback=fragment.has('access_token')||fragment.has('error')||callback.searchParams.has('token_hash')||callback.searchParams.has('error');
 if(hasCallback){
  const clean=new URL(callback);clean.hash='';
  for(const key of ['token_hash','type','error','error_code','error_description'])clean.searchParams.delete(key);
  history.replaceState(null,'',clean.href);
 }
 try{
  try{if(hasCallback)signedIn=await store.handleAuthCallback(callback.href);else await store.restoreSession();}
  catch(e){authError=e.message;}
  if(store.profile){loaded=true;render();}else await loadTraining();
  if(signedIn){localStorage.removeItem('training-pending-email');toast('Signed in successfully.');}
  if(authError)ownerLogin(undefined,authError);
 }finally{busy=false;}
}
async function loadTraining(){loadError='';try{await store.load();loaded=true;}catch(e){loaded=true;loadError=e.message;}render();}
function connect(){modal('Connect your Supabase project',form('<p class="helper">Run the supplied schema in your project’s SQL Editor, create a user in Authentication, and grant owner access before signing in. Demo records are not copied to Supabase.</p>'+field('Project URL','url',store.config.url||'','url',true)+field('Publishable key / legacy anon key','key',store.config.key||'','text',true)+'<p class="helper">Find these under Project Settings → API. Use a publishable key only. Your secret or service-role key must never be used in this app.</p>','Save connection'),async f=>{store.configure(f.get('url'),f.get('key'));location.reload();});}
function setup(){modal('Set up your shared workspace',`<div class="helper"><ol><li>Create a Supabase project for this restaurant.</li><li><a href="./supabase-schema.sql" download>Download the database schema</a> and run it in Supabase’s SQL Editor.</li><li>Create a leader account under Authentication → Users. Copy its user ID.</li><li>Run the owner-access SQL from the setup guide with that user ID. Assign additional leaders as trainers.</li><li>Enter the project URL and publishable key in Connection settings. For all devices, put those two public values in <code>config.js</code> before publishing.</li><li>Add your restaurant’s approved checklists, Pathway links, and team members. Test the same account on a second device.</li></ol><p>The preview is hosted privately with Sites. GitHub Pages publication and your Supabase account setup have not been completed.</p><p><a href="./SETUP.md" download>Download the detailed GitHub + Supabase guide</a> · <a href="./source.zip" download>Download app source backup</a></p></div>`);}
function install(){modal('One tap to your training',`<div class="helper"><h3>iPhone or iPad</h3><p>Open this app in Safari. Tap Share, then <strong>Add to Home Screen</strong>. Confirm the name and tap Add.</p><h3>Android</h3><p>Open in Chrome, open the menu, then select <strong>Install app</strong> or <strong>Add to Home screen</strong>.</p><p>Your cloud workspace requires a connection to sign in and save changes. The demo is specific to this browser.</p></div>`);}
function bind(){bindBohItemEditor();bindBuildControls(app);app.querySelectorAll('[data-department]').forEach(b=>b.onclick=()=>{itemDraft=null;department=b.dataset.department;localStorage.setItem('training-department',department);categoryId=null;sectionView=null;page='training';editing=false;render();});app.querySelector('#editor-category')?.addEventListener('change',e=>{categoryId=e.target.value;render();});app.querySelectorAll('[data-section-view]').forEach(b=>b.onclick=()=>{sectionView=b.dataset.sectionView;render();window.scrollTo(0,0);});app.querySelectorAll('[data-edit-section]').forEach(b=>b.onclick=()=>modal('Edit section heading',form(field('Section heading','section',b.dataset.editSection,'text',true)),async f=>{const name=f.get('section').trim();if(!name)throw Error('Enter a section heading.');await store.renameSection(categoryId,b.dataset.editSection,name);}));app.querySelectorAll('[data-add-section-item]').forEach(b=>b.onclick=()=>editItem(null,b.dataset.addSectionItem));app.querySelectorAll('[data-hide-item]').forEach(b=>b.onclick=()=>modal('Hide this training item?',form('<p class="helper">The item will be hidden from checklists and completion totals. You can restore it in Edit Training; existing progress is kept.</p>','Hide item'),async()=>{const item=store.data.items.find(i=>i.id===b.dataset.hideItem);await store.save('items',{...item,hidden:true});}));app.querySelectorAll('[data-restore-item]').forEach(b=>b.onclick=()=>run(async()=>{const item=store.data.items.find(i=>i.id===b.dataset.restoreItem);await store.save('items',{...item,hidden:false});toast('Item restored.');}));app.querySelectorAll('[data-overall-member]').forEach(el=>el.onchange=()=>run(async()=>{const member=store.data.members.find(m=>m.id===el.dataset.overallMember);await store.save('members',{...member,['status_'+department.toLowerCase()]:el.value});toast('Overall training status saved.');}));app.querySelectorAll('[data-check]').forEach(el=>el.onchange=()=>run(async()=>{await store.save('progress',{member_id:memberId,item_id:el.dataset.check,status:el.checked?'Trained':'Not started',updated_at:new Date().toISOString(),...(store.cloud?{recorded_by:store.session.user.id}:{})});toast('Checklist progress saved.');}));app.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>{itemDraft=null;page=b.dataset.nav;categoryId=null;sectionView=null;editing=false;search='';render();window.scrollTo(0,0);});app.querySelectorAll('[data-category]').forEach(b=>b.onclick=()=>{categoryId=b.dataset.category;sectionView=null;render();window.scrollTo(0,0);});app.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;render();});app.querySelector('#member-select')?.addEventListener('change',e=>{memberId=e.target.value;render();});app.querySelector('#search')?.addEventListener('input',e=>{search=e.target.value;const pos=e.target.selectionStart;render();const input=app.querySelector('#search');input.focus();input.setSelectionRange(pos,pos);});app.querySelectorAll('[data-status]').forEach(s=>s.onchange=()=>{const status=s.value;s.disabled=true;run(async()=>{await store.save('progress',{member_id:memberId,item_id:s.dataset.status,status,updated_at:new Date().toISOString(),...(store.cloud?{recorded_by:store.session.user.id}:{})});toast('Training progress saved.');}).finally(()=>{s.disabled=false;render();});});app.querySelectorAll('[data-edit-item]').forEach(b=>b.onclick=()=>editItem(store.data.items.find(i=>i.id===b.dataset.editItem)));app.querySelectorAll('[data-delete-item]').forEach(b=>b.onclick=()=>confirmDelete('items',b.dataset.deleteItem,store.data.items.find(i=>i.id===b.dataset.deleteItem).title));app.querySelectorAll('[data-edit-member]').forEach(b=>b.onclick=()=>editMember(store.data.members.find(i=>i.id===b.dataset.editMember)));app.querySelectorAll('[data-view-member]').forEach(b=>b.onclick=()=>{memberId=b.dataset.viewMember;page='progress';categoryId=null;render();window.scrollTo(0,0);});app.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>{const a=b.dataset.action;if(['home','back','logout'].includes(a))itemDraft=null;if(a==='edit-mode'){editing=!editing;render();}if(a==='open-editor'){page='editor';editing=true;sectionView=null;categoryId=categoryId||store.data.categories.find(c=>c.department===department)?.id;render();}if(a==='home'){page='training';categoryId=null;sectionView=null;editing=false;render();}if(a==='closing-back'){sectionView=null;render();}if(a==='back'){categoryId=null;render();}if(a==='welcome'){categoryId=store.data.categories.find(c=>/welcome/i.test(c.title))?.id;if(categoryId)render();else toast('Add a Welcome & Restaurant Tour category in Edit Training.');}if(a==='connect')connect();if(a==='owner-login')ownerLogin();if(a==='reload-training')loadTraining();if(a==='setup')setup();if(a==='install')install();if(a==='add-category')editCategory();if(a==='edit-category')editCategory(store.data.categories.find(c=>c.id===categoryId));if(a==='add-item')editItem();if(a==='add-member')editMember();if(a==='rename')modal('Restaurant name',form(field('Restaurant name','name',store.data.settings.name,'text',true)),async f=>{const name=f.get('name').trim();if(!name)throw Error('Enter a restaurant name.');await store.save('settings',{id:1,name});});if(a==='backup'){const blob=new Blob([JSON.stringify({exported_at:new Date().toISOString(),mode:store.cloud?'supabase':'demo',...store.data},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),anchor=document.createElement('a');anchor.href=url;anchor.download='training-backup-'+new Date().toISOString().slice(0,10)+'.json';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}if(a==='logout')run(async()=>store.logout());});}

render();if(store.cloud)initializeTraining();if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
setInterval(async()=>{if(store.cloud&&!busy&&!dialog.open&&!itemDraft&&document.visibilityState==='visible'){busy=true;try{await store.load();if(!itemDraft)render();}catch(e){toast('Shared updates unavailable: '+e.message,true);}finally{busy=false;}}},15000);
